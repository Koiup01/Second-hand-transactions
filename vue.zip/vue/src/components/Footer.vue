<template>
  <div style="height: 80px; padding: 10px 0; line-height: 30px; color: #666; text-align: center">
    <div>Copyright © 2004 - 2024 二手交易网 版权所有</div>
    <div>工商备案号：ICPxxxx9887739  <span style="margin-left: 20px">联系电话：010-88998877</span></div>
  </div>
</template>

<script>
export default {
  name: "Footer",
  data() {
    return {}
  },
  created() {

  },
  methods: {}
}
</script>

<style scoped>

</style>